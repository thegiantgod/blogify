const mongoose = require('mongoose');

const connectToDatabase = async () => {
    let dbUrl = "mongodb+srv://adminUser:adminUser@akkor.mqfuhxy.mongodb.net/Akkor";

    mongoose.connect(dbUrl);
    const db = mongoose.connection;

    db.on('error', console.error.bind(console, 'connection error:'));
    
    db.once('open', () => {
    console.log("Connection Successful!");
    });
}

module.exports = { connectToDatabase }